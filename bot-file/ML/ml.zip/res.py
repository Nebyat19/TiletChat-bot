import json
from flask import Flask,jsonify,request
from chat import get_response

import flask
  
app =   Flask(__name__)
  
  #               flask.render_template('filename.html')
@app.route('/', methods=['GET', 'POST'])
def home():
    response =jsonify({"data":True})
    response.headers.set('Access-Control-Allow-Origin', '*')
    return response
   
@app.route('/<save>/<time>', methods = ['GET'])   
def savefile(save,time):
    #x=request.get_data()
    
    #with open('file.txt', 'w') as f:
     #f.write("777")
    data = {
            "ok" : True,
            "save" : "txt",
        }
    response =jsonify(data)
    response.headers.set('Access-Control-Allow-Origin', '*')
    return "ok"
@app.route('/res/<key>/<time>', methods = ['GET'])
def ReturnJSON(key,time):
    if(request.method == 'GET'):
        data = {
            "ok" : True,
            "ans" : get_response(key),
        }
        response =jsonify(data)
        response.headers.set('Access-Control-Allow-Origin', '*')
        return response
  
if __name__=='__main__':
    app.run(debug=True)
